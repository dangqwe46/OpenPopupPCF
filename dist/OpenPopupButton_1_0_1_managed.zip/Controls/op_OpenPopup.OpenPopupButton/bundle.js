/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./OpenPopupButton/components/OpenPopupButtonView.tsx"
/*!************************************************************!*\
  !*** ./OpenPopupButton/components/OpenPopupButtonView.tsx ***!
  \************************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   OpenPopupButtonView: () => (/* binding */ OpenPopupButtonView)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react-components */ \"@fluentui/react-components\");\n/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__);\nfunction _slicedToArray(r, e) { return _arrayWithHoles(r) || _iterableToArrayLimit(r, e) || _unsupportedIterableToArray(r, e) || _nonIterableRest(); }\nfunction _nonIterableRest() { throw new TypeError(\"Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.\"); }\nfunction _unsupportedIterableToArray(r, a) { if (r) { if (\"string\" == typeof r) return _arrayLikeToArray(r, a); var t = {}.toString.call(r).slice(8, -1); return \"Object\" === t && r.constructor && (t = r.constructor.name), \"Map\" === t || \"Set\" === t ? Array.from(r) : \"Arguments\" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }\nfunction _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }\nfunction _iterableToArrayLimit(r, l) { var t = null == r ? null : \"undefined\" != typeof Symbol && r[Symbol.iterator] || r[\"@@iterator\"]; if (null != t) { var e, n, i, u, a = [], f = !0, o = !1; try { if (i = (t = t.call(r)).next, 0 === l) { if (Object(t) !== t) return; f = !1; } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0); } catch (r) { o = !0, n = r; } finally { try { if (!f && null != t.return && (u = t.return(), Object(u) !== u)) return; } finally { if (o) throw n; } } return a; } }\nfunction _arrayWithHoles(r) { if (Array.isArray(r)) return r; }\n\n\n/**\n * Styled Fluent UI v9 button that triggers the popup. Rendering does not depend on\n * the Xrm runtime, so it also draws correctly in the local PCF test harness.\n */\nvar OpenPopupButtonView = props => {\n  var _React$useState = react__WEBPACK_IMPORTED_MODULE_0__.useState(false),\n    _React$useState2 = _slicedToArray(_React$useState, 2),\n    busy = _React$useState2[0],\n    setBusy = _React$useState2[1];\n  var handleClick = react__WEBPACK_IMPORTED_MODULE_0__.useCallback(() => {\n    if (busy) {\n      return;\n    }\n    setBusy(true);\n    try {\n      props.onClick();\n    } finally {\n      // openPopup resolves on close; keep the button usable for re-open right away.\n      setBusy(false);\n    }\n  }, [busy, props]);\n  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.FluentProvider, {\n    theme: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.webLightTheme\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Button, {\n    appearance: \"primary\",\n    disabled: props.disabled,\n    onClick: handleClick\n  }, props.label));\n};\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./OpenPopupButton/components/OpenPopupButtonView.tsx?\n}");

/***/ },

/***/ "./OpenPopupButton/index.ts"
/*!**********************************!*\
  !*** ./OpenPopupButton/index.ts ***!
  \**********************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   OpenPopupButton: () => (/* binding */ OpenPopupButton)\n/* harmony export */ });\n/* harmony import */ var _components_OpenPopupButtonView__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./components/OpenPopupButtonView */ \"./OpenPopupButton/components/OpenPopupButtonView.tsx\");\n/* harmony import */ var _services_popup__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./services/popup */ \"./OpenPopupButton/services/popup.ts\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nclass OpenPopupButton {\n  constructor() {\n    this.returnData = \"\";\n    this.handleClick = () => {\n      var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k;\n      var p = this.context.parameters;\n      var popupProps = {\n        targetPageName: (_a = p.TargetPageName.raw) !== null && _a !== void 0 ? _a : \"\",\n        entityName: (_b = p.EntityName.raw) !== null && _b !== void 0 ? _b : undefined,\n        recordId: (_c = p.RecordId.raw) !== null && _c !== void 0 ? _c : undefined,\n        dialogTitle: (_d = p.DialogTitle.raw) !== null && _d !== void 0 ? _d : undefined,\n        dialogWidth: (_e = p.DialogWidth.raw) !== null && _e !== void 0 ? _e : undefined,\n        dialogHeight: (_f = p.DialogHeight.raw) !== null && _f !== void 0 ? _f : undefined,\n        sizeUnit: (_g = p.SizeUnit.raw) !== null && _g !== void 0 ? _g : undefined,\n        position: (_h = p.Position.raw) !== null && _h !== void 0 ? _h : undefined,\n        customParams: (_j = p.CustomParams.raw) !== null && _j !== void 0 ? _j : undefined,\n        storageKey: (_k = p.StorageKey.raw) !== null && _k !== void 0 ? _k : undefined\n      };\n      // Fire-and-forget: resolves when the popup closes, then pushes the output.\n      void (0,_services_popup__WEBPACK_IMPORTED_MODULE_1__.launchPopup)(this.context, popupProps).then(result => {\n        this.returnData = result;\n        this.notifyOutputChanged();\n        return result;\n      });\n    };\n    // Empty\n  }\n  init(context, notifyOutputChanged) {\n    this.context = context;\n    this.notifyOutputChanged = notifyOutputChanged;\n  }\n  updateView(context) {\n    this.context = context;\n    var rawLabel = context.parameters.ButtonLabel.raw;\n    var label = rawLabel && rawLabel.length > 0 ? rawLabel : \"Open\";\n    var props = {\n      label,\n      disabled: context.mode.isControlDisabled,\n      onClick: this.handleClick\n    };\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2__.createElement(_components_OpenPopupButtonView__WEBPACK_IMPORTED_MODULE_0__.OpenPopupButtonView, props);\n  }\n  getOutputs() {\n    return {\n      ReturnData: this.returnData\n    };\n  }\n  destroy() {\n    // No listeners to clean up.\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./OpenPopupButton/index.ts?\n}");

/***/ },

/***/ "./OpenPopupButton/services/popup.ts"
/*!*******************************************!*\
  !*** ./OpenPopupButton/services/popup.ts ***!
  \*******************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   buildNavOptions: () => (/* binding */ buildNavOptions),\n/* harmony export */   buildPageInput: () => (/* binding */ buildPageInput),\n/* harmony export */   launchPopup: () => (/* binding */ launchPopup)\n/* harmony export */ });\n/**\n * Popup service: builds the navigateTo page-input / navigation-options from the\n * control's manifest properties and opens the target custom page as a modal dialog.\n *\n * No Dataverse artifacts are created. When the dialog closes, the navigateTo promise\n * resolves; we return the stringified resolved value (usually empty for custom pages),\n * which the control exposes through the `ReturnData` output as a \"closed\" signal.\n */\nvar __awaiter = undefined && undefined.__awaiter || function (thisArg, _arguments, P, generator) {\n  function adopt(value) {\n    return value instanceof P ? value : new P(function (resolve) {\n      resolve(value);\n    });\n  }\n  return new (P || (P = Promise))(function (resolve, reject) {\n    function fulfilled(value) {\n      try {\n        step(generator.next(value));\n      } catch (e) {\n        reject(e);\n      }\n    }\n    function rejected(value) {\n      try {\n        step(generator[\"throw\"](value));\n      } catch (e) {\n        reject(e);\n      }\n    }\n    function step(result) {\n      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);\n    }\n    step((generator = generator.apply(thisArg, _arguments || [])).next());\n  });\n};\nvar DEFAULT_STORAGE_KEY = \"OpenPopupButton.ReturnData\";\n/**\n * Walk from the top-most window down to the current one and return the first\n * accessible `Xrm.Navigation.navigateTo`. Using the TOP-MOST app window is what\n * makes the dialog center on the whole model-driven app instead of the side pane\n * / custom page that hosts this control (that host runs in a nested iframe, so its\n * own Xrm centers the dialog within the pane).\n */\nfunction findWindowNavigateTo() {\n  var _a;\n  var wins = [];\n  try {\n    if (window.top && window.top !== window) {\n      wins.push(window.top);\n    }\n  } catch (_b) {\n    // Cross-origin top window — not accessible, skip.\n  }\n  try {\n    if (window.parent && window.parent !== window) {\n      wins.push(window.parent);\n    }\n  } catch (_c) {\n    // Cross-origin parent — skip.\n  }\n  wins.push(window);\n  for (var w of wins) {\n    try {\n      var nav = (_a = w.Xrm) === null || _a === void 0 ? void 0 : _a.Navigation;\n      if (nav && typeof nav.navigateTo === \"function\") {\n        return nav.navigateTo.bind(nav);\n      }\n    } catch (_d) {\n      // Inaccessible window — skip.\n    }\n  }\n  return undefined;\n}\nfunction resolveNavigateTo(context) {\n  // Prefer the top-most app window so the popup centers on the model-driven app,\n  // not the hosting side pane / custom page.\n  var fromWindow = findWindowNavigateTo();\n  if (fromWindow) {\n    return fromWindow;\n  }\n  // Last resort: the control's own (pane-scoped) navigation context.\n  var ctxNav = context.navigation;\n  if (ctxNav && typeof ctxNav.navigateTo === \"function\") {\n    return ctxNav.navigateTo.bind(ctxNav);\n  }\n  return undefined;\n}\nfunction saveToLocalStorage(key, value) {\n  try {\n    window.localStorage.setItem(key, value);\n  } catch (err) {\n    console.warn(\"[OpenPopupButton] Could not write to localStorage.\", err);\n  }\n}\nfunction parseCustomParams(raw) {\n  if (!raw) {\n    return {};\n  }\n  try {\n    var parsed = JSON.parse(raw);\n    return parsed && typeof parsed === \"object\" ? parsed : {};\n  } catch (_a) {\n    console.warn(\"[OpenPopupButton] CustomParams is not valid JSON; ignoring.\", raw);\n    return {};\n  }\n}\nfunction buildPageInput(props) {\n  var pageInput = {\n    pageType: \"custom\",\n    name: props.targetPageName\n  };\n  if (props.entityName) {\n    pageInput.entityName = props.entityName;\n  }\n  if (props.recordId) {\n    pageInput.recordId = props.recordId;\n  }\n  // Spread arbitrary custom params as extra keys; the custom page reads them via Param().\n  return Object.assign(Object.assign({}, pageInput), parseCustomParams(props.customParams));\n}\nfunction buildNavOptions(props) {\n  var unit = props.sizeUnit === \"px\" ? \"px\" : \"%\";\n  var options = {\n    target: 2,\n    // dialog / popup\n    position: props.position === 2 ? 2 : 1 // 2 = side, else center\n  };\n  if (props.dialogWidth && props.dialogWidth > 0) {\n    options.width = {\n      value: props.dialogWidth,\n      unit\n    };\n  }\n  if (props.dialogHeight && props.dialogHeight > 0) {\n    options.height = {\n      value: props.dialogHeight,\n      unit\n    };\n  }\n  if (props.dialogTitle) {\n    options.title = props.dialogTitle;\n  }\n  return options;\n}\n/**\n * Opens the popup and resolves when it closes.\n * @returns the stringified navigateTo result, or \"\" if nothing was returned.\n */\nfunction launchPopup(context, props) {\n  return __awaiter(this, void 0, void 0, function* () {\n    if (!props.targetPageName) {\n      console.warn(\"[OpenPopupButton] TargetPageName is empty; nothing to open.\");\n      return \"\";\n    }\n    var navigateTo = resolveNavigateTo(context);\n    if (!navigateTo) {\n      // Local test harness / no Xrm runtime: don't throw, just log.\n      console.warn(\"[OpenPopupButton] navigateTo is unavailable (running outside a model-driven runtime).\");\n      return \"\";\n    }\n    var pageInput = buildPageInput(props);\n    var navOptions = buildNavOptions(props);\n    try {\n      var result = yield navigateTo(pageInput, navOptions);\n      var output = result != null ? JSON.stringify(result) : \"\";\n      // Persist the output on close so the host (or any page) can read it back.\n      var key = props.storageKey && props.storageKey.length > 0 ? props.storageKey : DEFAULT_STORAGE_KEY;\n      saveToLocalStorage(key, output);\n      return output;\n    } catch (err) {\n      console.error(\"[OpenPopupButton] navigateTo failed.\", err);\n      return \"\";\n    }\n  });\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./OpenPopupButton/services/popup.ts?\n}");

/***/ },

/***/ "@fluentui/react-components"
/*!************************************!*\
  !*** external "FluentUIReactv940" ***!
  \************************************/
(module) {

module.exports = FluentUIReactv940;

/***/ },

/***/ "react"
/*!***************************!*\
  !*** external "Reactv16" ***!
  \***************************/
(module) {

module.exports = Reactv16;

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	const __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		const cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		const module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		if (!(moduleId in __webpack_modules__)) {
/******/ 			delete __webpack_module_cache__[moduleId];
/******/ 			const e = new Error("Cannot find module '" + moduleId + "'");
/******/ 			e.code = 'MODULE_NOT_FOUND';
/******/ 			throw e;
/******/ 		}
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			const getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter/value functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			if(Array.isArray(definition)) {
/******/ 				var i = 0;
/******/ 				while(i < definition.length) {
/******/ 					var key = definition[i++];
/******/ 					var binding = definition[i++];
/******/ 					if(!__webpack_require__.o(exports, key)) {
/******/ 						if(binding === 0) {
/******/ 							Object.defineProperty(exports, key, { enumerable: true, value: definition[i++] });
/******/ 						} else {
/******/ 							Object.defineProperty(exports, key, { enumerable: true, get: binding });
/******/ 						}
/******/ 					} else if(binding === 0) { i++; }
/******/ 				}
/******/ 			} else {
/******/ 				for(var key in definition) {
/******/ 					if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 						Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 					}
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	let __webpack_exports__ = __webpack_require__("./OpenPopupButton/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('OpenPopup.OpenPopupButton', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.OpenPopupButton);
} else {
	var OpenPopup = OpenPopup || {};
	OpenPopup.OpenPopupButton = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.OpenPopupButton;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}